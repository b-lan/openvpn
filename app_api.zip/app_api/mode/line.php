<?php
$regionno = false;
/**
 * 获取用户真实 IP
 */
function getIP()
{
	static $realip;
	if (isset($_SERVER)){
		if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
			$realip = $_SERVER["HTTP_X_FORWARDED_FOR"];
		} else if (isset($_SERVER["HTTP_CLIENT_IP"])) {
			$realip = $_SERVER["HTTP_CLIENT_IP"];
		} else {
			$realip = $_SERVER["REMOTE_ADDR"];
		}
	} else {
		if (getenv("HTTP_X_FORWARDED_FOR")){
			$realip = getenv("HTTP_X_FORWARDED_FOR");
		} else if (getenv("HTTP_CLIENT_IP")) {
			$realip = getenv("HTTP_CLIENT_IP");
		} else {
			$realip = getenv("REMOTE_ADDR");
		}
	}
	return $realip;
}

/**
 * 获取 IP  地理位置
 * 淘宝IP接口
 * @Return: array
 */
function getCity($ip = '')
{
    if($ip == ''){
        $url = "http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=json";
        $ip=json_decode(file_get_contents($url),true);
        $data = $ip;
    }else{
        $url="http://ip.taobao.com/service/getIpInfo.php?ip=".$ip;
        $ip=json_decode(file_get_contents($url));   
        if((string)$ip->code=='1'){
           return false;
        }
        $data = (array)$ip->data;
    }
    
    return $data;   
}

if(trim($_GET["s"]) == "")
{
	if($_SESSION["is_tmp_location"] && $_GET["location"] != "true")
	{
		$region = $_SESSION["region"];
		$isp = $_SESSION["isp"];
	}
	else
	{
		$is_location = true;
		$api_uri = "http://sq.75hu.com/api/getad.php?ip=".getIP();
		$json = file_get_contents($api_uri);
		$arr = json_decode($json,true);
		
		if($arr["data"]["isp"] == "")
		{
			$ispno = true;
		}
	
		$isp = '中国'.$arr["isp"]; //运行商 eg 电信
		$region = $arr["region"]; //份 eg 河北
		$city = $arr["city"]; //区 eg 保定
		$ip = $arr["ip"]; //用户IP eg 123.57.89.18
	}
	//$region = 
}
else
{
	$region = $_GET["s"];
	$isp = $_GET["i"];
	$_SESSION["region"] = $region;
	$_SESSION["isp"] = $isp;
	$_SESSION["is_tmp_location"] = true;
}

$find = str_replace("","",$region);
$find = str_replace("","",$find);
$find = str_replace("壮族自治区","",$find);
$find = str_replace("维吾尔自治区","",$find);
$find = str_replace("回族自治区","",$find);
$find = str_replace("自治区","",$find);

$line_grop = db('line_grop')->where(array("show"=>1))->order('id ASC')->select();
?>

<style  type="text/css">
.auto{
	background:#fff;
	padding-left:10px;
	height:40px;
	line-height:40px;
	border-top:1px solid #ccc;
}

.box01_list{
	list-style:none;
	margin:0px;
	padding:0px;
}
.sx{
	background:#328cc9;
	color:#fff;
	border:none;
	height:40px;
	margin:0px;
	float:right;
}
.breadcrumb{
	margin:0px;
}
.tip{
	color:#999;font-size:14px;
	padding:5px 0px;
}
</style>

<form action="?" method="GET">
<input name="act" value="line" type="hidden">
<input name="app_key" value="<?php echo $_GET["app_key"] ?>" type="hidden">
<input name="username" value="<?php echo $_GET["username"] ?>" type="hidden">
<input name="password" value="<?php echo $_GET["password"] ?>" type="hidden">


<div class="auto">
	地区
	<select name="s">
		<option value="<?php echo $region;?>">
			<?php echo $region;?>
			<?php echo $city;?>
		</option>
			<option>不限地区</option> 
			<option>北京</option> 
			<option>天津</option> 
			<option>上海</option> 
			<option>重庆</option>
			<option>河北</option>
			<option>山西</option>
			<option>山东</option>
			<option>辽宁</option> 
			<option>吉林</option> 
			<option>黑龙江</option> 
			<option>江苏</option> 
			<option>浙江</option> 
			<option>安徽</option> 
			<option>福建</option> 
			<option>江西</option> 
			<option>山东</option> 
			<option>河南</option> 
			<option>湖北</option> 
			<option>湖南</option> 
			<option>广东</option> 
			<option>海南</option> 
			<option>四川</option> 
			<option>贵州</option> 
			<option>云南</option> 
			<option>陕西</option> 
			<option>甘肃</option> 
			<option>宁夏</option> 
			<option>广西</option> 
			<option>新疆</option> 
			<option>西藏</option> 
			<option>青海</option> 
			<option>台湾</option>
			<option>香港</option>
			<option>澳门</option>
			<option>137</option>
			<option>138</option>
			<option>139</option>
			<option>53</option>
	</select>

	运营商
	<select name="i">
		<?php
			$i = 1;
			$p = "";
			foreach($line_grop as $vo)
			{
				if($vo["name"] == $isp)
				{
					$p = 'selected';
					$select_id = $vo["id"];
				}
				echo '<option value="'.$vo["name"].'" '.$p.'>'.$vo["name"].'</option>';
				$p = "";
			}
		?>
	</select>

	<input type="submit" class="sx" value="筛选线路">
</div>
	
	<ol class="breadcrumb">
	<div id="page-content">
    <div class="alert alert-info"># 首先点我
		<kbd><a href="?act=line&key=<?php echo $_GET["app_key"] ?>&username=<?php echo $_GET["username"] ?>&password=<?php echo $_GET["password"] ?>&location=true">[更新定位]</a></kbd>
		<br># 若是系统判定错误[ <?php echo $region; ?>]， 请手动修改
	</div>

</form>

    <div id="slider" class="swipe">
	
      <ul class="box01_list">
      
				<li class="li_list" style="<?php echo $ss?>">
					<div class="main"><ul class="list-group">
						
					<?php 
					$show = false;
						if(trim($region) == "" || $region == "不限地区"){
							$line = db('line')->where(array('show'=>'1','group'=>$select_id))->order('id DESC')->select();
						}else{
							$show = true;
							if(str_length(urldecode($region)) > 8){
								die("参数过长 len:".str_length(urldecode($region)));
							}
							$conn=mysql_connect('localhost','root','newpass');
							$result=mysql_db_query("llws", "SET NAMES UTF8", $conn);
							$line=mysql_db_query("llws", "SELECT * FROM line where name like '%".$find."%' OR label LIKE '%".$find."%'", $conn);
							//$line2=mysql_db_query("llws", "SELECT * FROM line where label LIKE '%全国%' OR label LIKE '%通用%' OR label LIKE '%不限地区%' OR 'name' LIKE '%全国%' OR 'name' LIKE '%通用%' OR 'name' LIKE '%不限地区%'", $conn);
							$line2=mysql_db_query("llws", "SELECT * FROM line where name like '%全国%' or name like '%通用%' or name like '%不限地区%' or label like '%全国%' or label like '%通用%' or label like '%不限地区%'", $conn);
							//$line2=mysql_db_query("llws", "SELECT * FROM line where name like '%137%'", $conn);
							//$line2 = db('line')->where("'show'=1 AND 'group'=:select_id AND (label LIKE '%全国%' OR label LIKE '%通用%' OR label LIKE '%不限地区%' OR 'name' LIKE '%全国%' OR 'name' LIKE '%通用%' OR 'name' LIKE '%不限地区%')",array(":select_id"=>$select_id))->order('id DESC')->select();
						}
						
						if($line){
							while ($vos=mysql_fetch_row($line)){?>
							<li class="list-group-item"><b>使用次数<?php echo "[".$vos['8']."]&nbsp"; echo $vos['2'];?></b>&nbsp;<span class="badge"><?php echo $vos['4']?></span><br>
								<p><?php echo $vos['6']?></p>
								<td class="text-right">
									<button type="button" class="btn btn-sm btn-info btn-effect-ripple" onclick="addLine('<?php echo $vos['0']?>')">
										安装
									</button>
								</td>
							</li>
								
						<?php }
						}else{
						?>
						<center>
							<div style="color:#ccc;font-size:12px;">暂无地区线路</div>
						</center>
						<?php
						}
						if(1){
						?>
						<center>
							<div class="tip">--=为您推荐全国线路=--</div>
						</center>
						<?php while ($vos=mysql_fetch_row($line2)){?>
							<li class="list-group-item"><b>使用次数<?php echo "[".$vos['8']."]&nbsp"; echo $vos['2'];?></b>&nbsp;<span class="badge"><?php echo $vos['4']?></span><br><p><?php echo $vos['6']?></p><td class="text-right"><button type="button" class="btn btn-sm btn-info btn-effect-ripple" onclick="addLine('<?php echo $vos['0']?>')">安装</button></li></td>
						<?php }
						} mysql_close($conn);?>
					</ul>
					<div style="clear:both"></div>
				</div>
			</li>
      </ul>
</div>


<script type="text/javascript">
$(function(){
	$(".gitem").click(function(){
		var n = $(".gitem").index(this);
		$(".gitem a").removeClass("active").eq(n).addClass("active");
		$(".li_list").hide().eq(n).show();
	});
});
</script>

<script>
	var name_tmp = "";
	function addLine(id){
		$.post(
			'getLine.php',
			{
				'id':id,
				'key':'<?php echo $_GET["app_key"] ?>',
				'username':'<?php echo $_GET["username"] ?>',
				'password':'<?php echo $_GET["password"] ?>'
			},function(data){
				if(data.status == 'success'){
					//window.myObj.writeFile('test.ovpn','<?php echo base64_encode(file_get_contents('1.ovpn'))?>','download');
					name_tmp = data.name;
					window.myObj.writeFile(data.name+'.ovpn',data.content,'download'); 
				}else{
					alert(data.msg);
				}
			},"JSON");
		  
	}
	function cli_sendData(status,type,msg){
		if(type == 'file_w'){
			if(status == 'success'){
				window.myObj.installPro('download/'+name_tmp+'.ovpn');
			}else{
				$('.tip').html("写入文件失败");
			}
		}
	}
</script>
