<?php
require("system.php");//引入新的操作接口
$admin = db("app_admin")->where(array("username"=>$_SESSION["dd"]["username"],"password"=>$_SESSION["dd"]["password"]))->find();
		if(!$admin){
			if(!$login_allow){
				$status['status'] = "error";
				die(json_encode($status));
				exit;
			}
		
		}
$act = $_GET['my'];
switch($act){
	case "outline" :
		system(R."/sha \"".$_POST['user']."\"");
	break;
	case "outline_udp" :
		system(R."/sha2 \"".$_POST['user']."\"");
	break;
	case "addll" :
		$nums = $_POST['n'];

		$db = db(_openvpn_);
		$info = $db->where(array(_iuser_=>$_POST['user']))->find();
		$addll = $nums*1024*1024*1024;
		
			$update["maxll"] = $addll;
			$update["endtime"] = time()+30*24*60*60;
			$update["isent"] = "0";
			$update["irecv"] = "0";
			$update["i"] = "1";
	
		if($db->where(array('iuser'=>$_POST['user']))->update($update)){
			$status['status'] = "success";
			die(json_encode($status));
		}else{
			$status['status'] = "error";
			die(json_encode($status));
		}
	break;
}