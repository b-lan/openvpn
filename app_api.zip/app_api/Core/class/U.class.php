<?php

include_once('/var/www/html/mianliu/library/config_read.php');
include '/var/www/html/mianliu/library/opendb.php';

//获取套餐信息
function get_user_total_traffic($username){
   global $dbSocket;
   global $configValues;
    $max_global_traffic = 0;
    $max_active_days = 0;
    $query_sql = "SELECT groupname FROM ".$configValues['CONFIG_DB_TBL_RADUSERGROUP']." WHERE username = '$username'";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        $groupname = $row[0];
          $query_sql1 = "SELECT * FROM ".$configValues['CONFIG_DB_TBL_RADGROUPCHECK']." WHERE groupname = '$groupname'";
          $re1=$dbSocket->query($query_sql1);
          while($row1=$re1->fetchRow()){
              if ("Max-Global-Traffic" == $row1[2]){
                  $max_global_traffic = $row1[4];
              }elseif("Max-Active-Days" == $row1[2]){
                  $max_active_days = $row1[4];
              }
          }

    }
    $max=array();
    $max[0]=$max_global_traffic;
    $max[1]=$max_active_days;
    return $max;

}

//获取使用天数
function get_user_used_days($username){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT IF(COUNT(radacctid>=1),(UNIX_TIMESTAMP() - IFNULL(UNIX_TIMESTAMP(AcctStartTime),0)),0) DIV 86400 FROM ".$configValues['CONFIG_DB_TBL_RADACCT']." WHERE username = '$username' AND AcctSessionTime >= 1 ORDER BY AcctStartTime LIMIT 1";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        return $row[0];
    }else{
        return false;
    }

}

//获取流量
function get_user_used_traffic($username){
   global $dbSocket;
   global $configValues;
    $query_sql = "SELECT SUM(acctinputoctets + acctoutputoctets) FROM ".$configValues['CONFIG_DB_TBL_RADACCT']." WHERE username = '$username';";
    $re = $dbSocket->query($query_sql);
    if($row = $re->fetchRow()){
        if ($row[0] <> ''){
                return $row[0];
        }else{
                return 0;
        }
    }else{
        return false;
    }
}

//获取用户信息
function get_userinfo_username($username, $pass)
{
	global $dbSocket;
	global $configValues;
	
	$query_sql = "SELECT * FROM ".$configValues['CONFIG_DB_TBL_RADCHECK']." WHERE username = '$username'";
	$re = $dbSocket->query($query_sql);
	if($row = $re->fetchRow())
	{
		$db_username = $row[1];
		$db_attribute = $row[2];
		$db_op = $row[3];
		$db_value = $row[4];
		
		if ($pass != NULL && $db_value != $pass)
		{
			return false;
		}
		
		if ($username == $db_username) //判断用户是否存在
		{
			//套餐
			$umax = get_user_total_traffic($username);
			$max_global_traffic=$umax[0]*1024*1024;
			$max_active_days=$umax[1];
			
			if ($max_global_traffic == 0)
			{
				$max_global_traffic = 99999999999;
			}
			
			if ($max_active_days == 0)
			{
				$max_active_days = 888;
			}
			
			//天数
			$activeDaysCount = get_user_used_days($username);
			//流量
			$cur_traffic = get_user_used_traffic($username);
			
			
			$info[iuser] = $db_username;
			$info[pass] = $db_value;
			$info[isent] = $cur_traffic/2;
			$info[irecv] = $cur_traffic/2;
			$info[maxll] = $max_global_traffic;
			$info[max_active_days] = $max_active_days;
			$info[activeDaysCount] = $activeDaysCount;
			
			$info[i] = 1;
			
			return $info;
		}
		else
		{
			return false;
		}
	}
}

class U{
	private $user;
	private $db;
	public $isuser = false;
	private $username;

	public function __construct($username,$password="",$check=false)
	{
		$this->username = $username;
		$password = trim($password);
		
		
		if($password == "" && $check == false)
		{
			$info = get_userinfo_username($username, NULL);
		}
		else //强制要求验证
		{
			$info = get_userinfo_username($username, $password);
		}
		/*
		$this->db = db(_openvpn_);
		$db = $this->db;
		if($password == "" && $check == false){
			$info = $db->where(array(_iuser_=>$username))->find();
		}else{
			//强制要求验证
			$info = $db->where(array(_iuser_=>$username,_ipass_=>$password))->find();
		}
		*/
		if($info != false)
		{
			$this->isuser = true;
			$this->user = $info;
		}else{
			$this->user = array();
		}
	}

	public function getNative(){
		return $this->user;
	}

	public function getDataused(){
		//获取已经使用的流量
		$user = $this->user;
		$irecv = $user[_irecv_];
		$isent = $user[_isent_];
		$used = $irecv+$isent;
		return $used;
	}

	public function getDatasurplus(){
		//流量剩余
		$user = $this->user;
		$used = $this->getDataused();
		$max = $user[_maxll_];
		$surplus = $max - $used;
		return $surplus;
	}

	public function getDatamax(){
		$user = $this->user;
		$max = $user[_maxll_];
		return $max;
	}
	public function getDatadays(){
		$uinfo = $this->user;
		return $uinfo[max_active_days]-$uinfo[activeDaysCount];
	}
	public function setStop(){
		return $this->db->where(array(_iuser_=>$this->username))->update(array(_i_=>"0"));
	}
	
	public function setStart(){
		return $this->db->where(array(_iuser_=>$this->username))->update(array(_i_=>"1"));
	}
}
